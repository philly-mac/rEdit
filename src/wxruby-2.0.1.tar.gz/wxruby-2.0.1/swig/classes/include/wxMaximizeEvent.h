// wxMaximizeEvent.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxMaximizeEvent_h_)
#define _wxMaximizeEvent_h_
class wxMaximizeEvent : public wxEvent
{
public:
	/**
	 * \brief Constructor. 
	 * \param int   
	*/

   wxMaximizeEvent(int  id = 0) ;
};


#endif
