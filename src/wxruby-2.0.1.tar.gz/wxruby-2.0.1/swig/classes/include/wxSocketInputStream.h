// wxSocketInputStream.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxSocketInputStream_h_)
#define _wxSocketInputStream_h_
class wxSocketInputStream : public wxInputStream
{
public:
	/**
	 * \brief Creates a new read-only socket stream using the specified initialized
socket connection. 
	 * \param wxSocketBase&  
	*/

   wxSocketInputStream(wxSocketBase&  s ) ;
};


#endif
