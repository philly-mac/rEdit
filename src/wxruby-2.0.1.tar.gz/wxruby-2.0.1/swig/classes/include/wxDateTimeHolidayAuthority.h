// wxDateTimeHolidayAuthority.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxDateTimeHolidayAuthority_h_)
#define _wxDateTimeHolidayAuthority_h_
class wxDateTimeHolidayAuthority
{
public:
};


#endif
