// wxDateTimeWorkDays.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxDateTimeWorkDays_h_)
#define _wxDateTimeWorkDays_h_
class wxDateTimeWorkDays
{
public:
};


#endif
