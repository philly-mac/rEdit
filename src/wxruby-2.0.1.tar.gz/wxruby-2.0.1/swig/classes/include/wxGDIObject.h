// wxGDIObject.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxGDIObject_h_)
#define _wxGDIObject_h_
class wxGDIObject : public wxObject
{
public:
	/**
	 * \brief Default constructor. 
	*/

   wxGDIObject() ;
  // the following were missing from the xml
  virtual ~wxGDIObject();
};


#endif
