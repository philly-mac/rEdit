// wxMultipleChoiceDialog.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxMultipleChoiceDialog_h_)
#define _wxMultipleChoiceDialog_h_
class wxMultipleChoiceDialog : public wxDialog
{
public:
};


#endif
