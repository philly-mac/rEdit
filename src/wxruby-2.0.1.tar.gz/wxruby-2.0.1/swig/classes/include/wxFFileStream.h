// wxFFileStream.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxFFileStream_h_)
#define _wxFFileStream_h_
class wxFFileStream : public wxFFileOutputStream
{
public:
	/**
	 * \brief Initializes a new file stream in read-write mode using the specified 
  name. 
	 * \param const wxString&  
	*/

   wxFFileStream(const wxString&  iofileName ) ;
};


#endif
