// wxSocketOutputStream.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxSocketOutputStream_h_)
#define _wxSocketOutputStream_h_
class wxSocketOutputStream : public wxOutputStream
{
public:
	/**
	 * \brief Creates a new write-only socket stream using the specified initialized
socket connection. 
	 * \param wxSocketBase&  
	*/

   wxSocketOutputStream(wxSocketBase&  s ) ;
};


#endif
