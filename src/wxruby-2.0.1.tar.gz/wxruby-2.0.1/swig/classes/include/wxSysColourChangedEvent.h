// wxSysColourChangedEvent.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxSysColourChangedEvent_h_)
#define _wxSysColourChangedEvent_h_
class wxSysColourChangedEvent : public wxEvent
{
public:
	/**
	 * \brief Constructor. 
	*/

   wxSysColourChanged() ;
};


#endif
