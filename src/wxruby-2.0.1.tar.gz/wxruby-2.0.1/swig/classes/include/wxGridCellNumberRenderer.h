// Copyright 2004-2007, wxRuby development team
// released under the MIT-like wxRuby2 license

#if !defined(_wxGridCellNumberRenderer_h_)
#define _wxGridCellNumberRenderer_h_
class wxGridCellNumberRenderer : public wxGridCellStringRenderer
{
public:
   wxGridCellNumberRenderer() ;
};


#endif
