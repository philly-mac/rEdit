// wxDebugStreamBuf.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxDebugStreamBuf_h_)
#define _wxDebugStreamBuf_h_
class wxDebugStreamBuf
{
public:
};


#endif
