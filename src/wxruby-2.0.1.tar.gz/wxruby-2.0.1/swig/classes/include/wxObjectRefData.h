// wxObjectRefData.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxObjectRefData_h_)
#define _wxObjectRefData_h_
class wxObjectRefData
{
public:
	/**
	 * \brief Default constructor. Initialises the   member to 1. 
	*/

   wxObjectRefData() ;
	/**
	 * \brief Destructor. 
	*/

  virtual  ~wxObjectRefData() ;
};


#endif
