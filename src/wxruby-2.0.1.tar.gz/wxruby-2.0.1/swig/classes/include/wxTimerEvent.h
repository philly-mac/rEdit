// wxTimerEvent.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxTimerEvent_h_)
#define _wxTimerEvent_h_
class wxTimerEvent
{
public:
	/**
	 * \brief Returns the interval of the timer which generated this event. 
	*/

  int GetInterval() const;
};


#endif
