// wxLogStderr.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxLogStderr_h_)
#define _wxLogStderr_h_
class wxLogStderr : public wxLog
{
public:
	/**
	 * \brief Constructs a log target which sends all the log messages to the given
 . If it is  , the messages are sent to  . 
	 * \param FILE   
	*/

   wxLogStderr(FILE  *fp = NULL) ;
};


#endif
