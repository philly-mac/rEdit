// wxLogGui.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxLogGui_h_)
#define _wxLogGui_h_
class wxLogGui : public wxLog
{
public:
	/**
	 * \brief Default constructor. 
	*/

   wxLogGui() ;
};


#endif
