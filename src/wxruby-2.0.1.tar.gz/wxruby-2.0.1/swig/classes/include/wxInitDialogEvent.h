// wxInitDialogEvent.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxInitDialogEvent_h_)
#define _wxInitDialogEvent_h_
class wxInitDialogEvent : public wxEvent
{
public:
	/**
	 * \brief Constructor. 
	 * \param int   
	*/

   wxInitDialogEvent(int  id = 0) ;
};


#endif
