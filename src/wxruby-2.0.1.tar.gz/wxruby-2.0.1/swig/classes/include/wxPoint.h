// wxPoint.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxPoint_h_)
#define _wxPoint_h_
class wxPoint
{
public:
	/**
	 * \brief  
	*/

   wxPoint() ;
	/**
	 * \brief Create a point. 
	 * \param int  
	 * \param int  
	*/

   wxPoint(int  x , int  y ) ;
  // the following were missing from the xml
  int x;
  int y;
};


#endif
