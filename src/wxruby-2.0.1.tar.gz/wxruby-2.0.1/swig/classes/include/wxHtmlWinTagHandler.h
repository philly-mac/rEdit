// wxHtmlWinTagHandler.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxHtmlWinTagHandler_h_)
#define _wxHtmlWinTagHandler_h_
class wxHtmlWinTagHandler : public wxHtmlTagHandler
{
public:
};


#endif
