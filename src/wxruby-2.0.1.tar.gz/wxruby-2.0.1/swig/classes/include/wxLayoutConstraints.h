// wxLayoutConstraints.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxLayoutConstraints_h_)
#define _wxLayoutConstraints_h_
class wxLayoutConstraints : public wxObject
{
public:
	/**
	 * \brief Constructor. 
	*/

   wxLayoutConstraints() ;
  // the following were missing from the xml
  wxIndividualLayoutConstraint bottom;
  wxIndividualLayoutConstraint height;
  wxIndividualLayoutConstraint left;
  wxIndividualLayoutConstraint right;
  wxIndividualLayoutConstraint top;
  wxIndividualLayoutConstraint width;
  wxIndividualLayoutConstraint centreX;
  wxIndividualLayoutConstraint centreY;
};


#endif
