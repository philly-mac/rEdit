// wxZipInputStream.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxZipInputStream_h_)
#define _wxZipInputStream_h_
class wxZipInputStream : public wxInputStream
{
public:
	/**
	 * \brief Constructor. 
	 * \param const wxString&   
	 * \param const wxString&   
	*/

   wxZipInputStream(const wxString&  archive , const wxString&  file ) ;
};


#endif
