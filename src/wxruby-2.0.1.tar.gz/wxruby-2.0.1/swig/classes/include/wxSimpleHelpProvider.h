// Copyright 2004-2008, wxRuby development team
// released under the MIT-like wxRuby2 license

// IGNORE - implemented in pure ruby: lib/wx/classes/simplehelpprovider.rb
#if !defined(_wxSimpleHelpProvider_h_)
#define _wxSimpleHelpProvider_h_
class wxSimpleHelpProvider : public wxHelpProvider
{
public:
};


#endif
