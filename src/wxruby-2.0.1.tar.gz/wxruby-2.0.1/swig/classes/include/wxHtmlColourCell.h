// wxHtmlColourCell.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxHtmlColourCell_h_)
#define _wxHtmlColourCell_h_
class wxHtmlColourCell : public wxHtmlCell
{
public:
	/**
	 * \brief Constructor. 
	 * \param wxColour   
	 * \param int   
	*/

   wxHtmlColourCell(wxColour  clr , int  flags = wxHTML_CLR_FOREGROUND) ;
};


#endif
