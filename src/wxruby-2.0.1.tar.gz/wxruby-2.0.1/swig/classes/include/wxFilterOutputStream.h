// wxFilterOutputStream.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxFilterOutputStream_h_)
#define _wxFilterOutputStream_h_
class wxFilterOutputStream : public wxOutputStream
{
public:
	/**
	 * \brief Initializes a &quot;filter&quot; stream. 
	 * \param wxOutputStream&  
	*/

   wxFilterOutputStream(wxOutputStream&  stream ) ;
};


#endif
