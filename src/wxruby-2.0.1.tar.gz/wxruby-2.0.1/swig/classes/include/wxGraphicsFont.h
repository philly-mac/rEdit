// Copyright 2004-2007, wxRuby development team
// released under the MIT-like wxRuby2 license

#if !defined(_wxGraphicsFont_h_)
#define _wxGraphicsFont_h_

class wxGraphicsFont : public wxGraphicsObject
{
public :
  wxGraphicsFont();
  virtual ~wxGraphicsFont();
} ;


#endif
