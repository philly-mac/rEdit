// wxClientDC.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxClientDC_h_)
#define _wxClientDC_h_
class wxClientDC : public wxWindowDC
{
public:
	/**
	 * \brief Constructor. Pass a pointer to the window on which you wish to paint. 
	 * \param wxWindow*  
	*/

   wxClientDC(wxWindow*  window ) ;
};


#endif
