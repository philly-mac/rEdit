// wxLogTextCtrl.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxLogTextCtrl_h_)
#define _wxLogTextCtrl_h_
class wxLogTextCtrl : public wxLog
{
public:
	/**
	 * \brief Constructs a log target which sends all the log messages to the given text
control. The   parameter cannot be  . 
	 * \param wxTextCtrl   
	*/

   wxLogTextCtrl(wxTextCtrl  *textctrl ) ;
};


#endif
