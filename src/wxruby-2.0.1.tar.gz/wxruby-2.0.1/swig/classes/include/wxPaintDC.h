// wxPaintDC.h
// This file was automatically generated
// by extractxml.rb, part of the wxRuby project
// Do not make changes directly to this file!

#if !defined(_wxPaintDC_h_)
#define _wxPaintDC_h_
class wxPaintDC : public wxWindowDC
{
public:
	/**
	 * \brief Constructor. Pass a pointer to the window on which you wish to paint. 
	 * \param wxWindow*  
	*/

   wxPaintDC(wxWindow*  window ) ;
  // the following were missing from the xml
  virtual ~wxPaintDC();
};


#endif
