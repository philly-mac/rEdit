# This module contains various utilities to simplify the implementation of the WxRuby Demo

module WxDemoUtilities
    
    #Convert paths to the platform-specific separator
    
    def opj(path)
        
    end

    #----------------------------------------------------------
end