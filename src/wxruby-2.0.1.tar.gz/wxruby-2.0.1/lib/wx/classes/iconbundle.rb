class Wx::IconBundle
  alias :<< :add_icon
end
