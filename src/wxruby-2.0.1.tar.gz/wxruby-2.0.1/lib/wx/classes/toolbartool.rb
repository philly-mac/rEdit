class Wx::ToolBarTool
  alias :id :get_id
  alias :wx_id :get_id
end
