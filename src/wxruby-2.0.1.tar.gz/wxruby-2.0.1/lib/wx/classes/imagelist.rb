class Wx::ImageList
  alias :<< :add
end
