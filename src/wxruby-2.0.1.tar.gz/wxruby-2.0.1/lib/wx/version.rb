module Wx
  WXRUBY_VERSION    = '2.0.1'
end
